// engine/scoring.mjs
// The heart of the engine. Converts computed features into the narrative data
// contract. Nothing here is authored: every score, status, bias, and the prose
// evidence/psychology lines are derived from the feature numbers, so each claim
// is reproducible and explainable from inputs.

import { clamp, mean, toSignedScore } from "./indicators.mjs";

const r1 = (x) => Math.round(x * 10) / 10;
const ri = (x) => Math.round(x);

/** Map magnitude of `value` to 0–100 given a saturation `scale`. */
function intensity(value, scale) {
  if (!Number.isFinite(value) || scale <= 0) return 0;
  return clamp(ri((Math.min(Math.abs(value) / scale, 1)) * 100), 0, 100);
}

/** Classify a signed value into a risk bias, with a neutral dead-zone. */
function bias(value, dead, positiveIsRiskOn = true) {
  if (!Number.isFinite(value) || Math.abs(value) < dead) return "mixed";
  const up = value > 0;
  if (positiveIsRiskOn) return up ? "risk-on" : "risk-off";
  return up ? "risk-off" : "risk-on";
}

// ---- Definitions: how each narrative reads the cross-asset tape ----------

export const NARRATIVES = [
  {
    id: "ai-supercycle-fatigue",
    title: "AI supercycle narrative losing breadth",
    lens: "divergence",
    representative: "SMH",
    affectedTickers: ["NVDA", "AMD", "SMH", "MSFT"],
    pulses(f) {
      return [
        {
          asset: "SMH",
          reading: f.semiMomentum >= 0 ? "Momentum leadership" : "Momentum stalling",
          bias: bias(f.semiMomentum, 1.5, true),
          strength: intensity(f.semiMomentum, 12)
        },
        {
          asset: "QQQE",
          reading: f.techBreadth < 45 ? "Breadth fading" : "Breadth holding",
          bias: f.techBreadth >= 55 ? "risk-on" : f.techBreadth <= 45 ? "risk-off" : "mixed",
          strength: clamp(ri(Math.abs(f.techBreadth - 50) * 1.7) + 20, 20, 100)
        },
        {
          asset: "10Y Yield",
          reading: "Discount-rate pressure",
          bias: bias(f.yieldPressure, 0.4, false),
          strength: intensity(f.yieldPressure, 1.4)
        }
      ];
    },
    summary(f) {
      return `Semiconductor leadership is ${f.semiMomentum >= 0 ? "intact" : "fading"} (${r1(
        f.semiMomentum
      )}% / 20 bars) while broad-tech participation sits at ${ri(f.techBreadth)}/100, leaving the AI-growth story narrowly carried.`;
    },
    evidence(f) {
      return [
        `Semis returned ${r1(f.semiMomentum)}% over 20 bars while equal-weight tech breadth reads ${ri(
          f.techBreadth
        )}/100.`,
        `Semis-vs-broad relative strength slope is ${r1(f.semiVsBroad)} — leadership ${
          f.semiVsBroad > 0 ? "concentrating" : "broadening"
        }.`,
        `10Y yield trend of ${r1(f.yieldPressure)} is ${
          f.yieldPressure > 0 ? "adding discount-rate pressure to" : "easing pressure on"
        } long-duration growth.`
      ];
    },
    psychology(f) {
      return f.techBreadth < 45 && f.semiMomentum > 0
        ? "Crowding risk: traders are extrapolating winners while ignoring narrowing confirmation."
        : "Participation watch: leadership is broad enough that the AI trade is not yet over-concentrated.";
    }
  },
  {
    id: "equity-bond-contradiction",
    title: "Bond market contradicting equity optimism",
    lens: "regime_contradiction",
    representative: "SPY",
    affectedTickers: ["SPY", "QQQ", "TLT", "IWM"],
    pulses(f) {
      return [
        {
          asset: "SPY",
          reading: f.equityTrend >= 0 ? "Index optimism" : "Index softening",
          bias: bias(f.equityTrend, 1, true),
          strength: intensity(f.equityTrend, 8)
        },
        {
          asset: "TLT",
          reading: f.durationReturn < 0 ? "Weak duration bid" : "Duration bid building",
          bias: f.durationReturn > 0.3 ? "risk-off" : f.durationReturn < -0.3 ? "risk-on" : "mixed",
          strength: intensity(f.durationReturn, 6)
        },
        {
          asset: "MOVE/VIX",
          reading: "Rates stress premium",
          bias: "risk-off",
          strength: clamp(ri((f.ratesVsEquityVol - 4) * 14), 0, 100)
        }
      ];
    },
    summary(f) {
      return `Equity indices are pricing ${f.equityTrend >= 0 ? "resilient growth" : "caution"} (${r1(
        f.equityTrend
      )}% / 20 bars) while the MOVE/VIX ratio at ${r1(
        f.ratesVsEquityVol
      )} shows rates markets less convinced.`;
    },
    evidence(f) {
      return [
        `SPY is ${r1(f.equityTrend)}% over 20 bars while small caps lag by ${r1(f.smallCapLag)} points.`,
        `Treasury volatility vs equity volatility (MOVE/VIX) sits at ${r1(
          f.ratesVsEquityVol
        )} — ${f.ratesVsEquityVol > 6 ? "elevated rates stress" : "broadly aligned"}.`,
        `Long-duration bid reads ${r1(f.durationReturn)}% — ${
          f.durationReturn < 0
            ? `no safety flight ${f.equityTrend >= 0 ? "despite the equity rally" : "even as equities soften"}`
            : "some defensive accumulation underway"
        }.`
      ];
    },
    psychology(f) {
      return f.equityTrend > 0 && f.ratesVsEquityVol > 6
        ? "Confirmation bias: equity traders accept soft-landing headlines faster than rates markets validate them."
        : "Cross-checked tape: equity and rates signals are currently in rough agreement.";
    }
  },
  {
    id: "vol-term-stress",
    title: "Soft-landing pricing with volatility stress underneath",
    lens: "cross_asset_confirmation",
    representative: "SPY",
    affectedTickers: ["SPY", "VIX", "VIXY", "HYG"],
    pulses(f) {
      return [
        {
          asset: "VIX Spot",
          reading: f.levels.vix < 18 ? "Surface calm" : "Volatility elevated",
          bias: f.levels.vix < 18 ? "risk-on" : "risk-off",
          strength: clamp(ri(Math.abs(18 - f.levels.vix) * 6) + 15, 15, 100)
        },
        {
          asset: "SPX Skew",
          reading: "Protection demand",
          bias: f.spxSkewRank > 55 ? "risk-off" : "mixed",
          strength: clamp(ri(Math.abs(f.spxSkewRank - 50) * 1.6), 0, 100)
        },
        {
          asset: "HYG",
          reading: f.creditTrend >= 0 ? "Credit stable" : "Credit softening",
          bias: f.creditTrend >= 0 ? "risk-on" : "risk-off",
          strength: intensity(f.creditTrend, 4)
        },
        {
          asset: "SPX IV",
          reading: f.ivTrend > 0 ? "Vol bid building" : "Vol bid easing",
          bias: f.ivTrend > 0 ? "risk-off" : "risk-on",
          strength: intensity(f.ivTrend, 1.2)
        }
      ];
    },
    summary(f) {
      return `Spot looks calm (VIX ${r1(f.levels.vix)}, drawdown ${r1(
        f.spyDrawdown
      )}%) but skew sits in the ${ri(f.spxSkewRank)}th percentile — the tape is still paying for downside protection.`;
    },
    evidence(f) {
      return [
        `SPX put skew is in the ${ri(f.spxSkewRank)}th percentile of its own history.`,
        `Credit (HYG) trend is ${r1(f.creditTrend)}% — ${
          f.creditTrend >= 0 ? "not deteriorating" : "starting to soften"
        } even as hedging demand rises.`,
        `SPX implied-vol slope of ${r1(f.ivTrend)} shows vol buyers ${
          f.ivTrend > 0 ? "active before visible price weakness" : "stepping back"
        }.`
      ];
    },
    psychology(f) {
      return f.spxSkewRank > 55 && f.spyDrawdown > -3
        ? "Surface calm, hidden caution: traders are not panicking, but they are quietly paying for insurance."
        : "Aligned hedging: protection demand is consistent with realized price action.";
    }
  },
  {
    id: "retail-liquidity-detachment",
    title: "Retail call activity detached from liquidity backdrop",
    lens: "market_psychology",
    representative: "ARKK",
    affectedTickers: ["TSLA", "COIN", "MARA", "ARKK"],
    pulses(f) {
      return [
        {
          asset: "ARKK",
          reading: "Speculative demand",
          bias: f.speculativeDemand >= 0 ? "risk-on" : "risk-off",
          strength: intensity(f.speculativeDemand, 10)
        },
        {
          asset: "Retail Calls",
          reading: f.callZ > 0 ? "Call chase active" : "Call demand cooling",
          bias: f.callZ > 0.3 ? "risk-on" : "mixed",
          strength: intensity(f.callZ, 1.6)
        },
        {
          asset: "DXY",
          reading: "Liquidity headwind",
          bias: bias(f.liquidityHeadwind, 0.4, false),
          strength: intensity(f.liquidityHeadwind, 1.2)
        },
        {
          asset: "IWM",
          reading: f.betaBreadth < 45 ? "Weak beta breadth" : "Beta breadth firm",
          bias: f.betaBreadth >= 55 ? "risk-on" : f.betaBreadth <= 45 ? "risk-off" : "mixed",
          strength: clamp(ri(Math.abs(f.betaBreadth - 50) * 1.6) + 20, 20, 100)
        }
      ];
    },
    summary(f) {
      return `Speculative call demand reads z=${r1(f.callZ)} in high-beta names while a ${
        f.liquidityHeadwind > 0 ? "rising" : "easing"
      } dollar and ${ri(f.betaBreadth)}/100 beta breadth argue for selectivity.`;
    },
    evidence(f) {
      return [
        `Average call-volume z-score across retail favorites is ${r1(f.callZ)}.`,
        `Dollar (DXY) trend of ${r1(f.liquidityHeadwind)} is ${
          f.liquidityHeadwind > 0 ? "a liquidity headwind" : "a liquidity tailwind"
        } for speculative risk.`,
        `Beta breadth (IWM/ARKK/COIN above MA) reads ${ri(
          f.betaBreadth
        )}/100 — ${f.betaBreadth < 50 ? "not confirming" : "confirming"} the call demand.`
      ];
    },
    psychology(f) {
      return f.callZ > 0.3 && (f.liquidityHeadwind > 0 || f.betaBreadth < 50)
        ? "FOMO impulse: options demand is front-running confirmation from liquidity and breadth."
        : "Demand with backing: speculative flow is currently corroborated by liquidity and breadth.";
    }
  }
];

// ---- Generic field derivation (shared across narratives) -----------------

export function contradictionFromPulses(pulses) {
  let on = 0;
  let off = 0;
  const all = [];
  for (const p of pulses) {
    all.push(p.strength);
    if (p.bias === "risk-on") on += p.strength;
    else if (p.bias === "risk-off") off += p.strength;
  }
  const denom = Math.max(on, off);
  const balance = denom > 0 ? Math.min(on, off) / denom : 0; // 1 = perfectly opposed
  const magnitude = all.length ? mean(all) / 100 : 0; // 0..1 overall activity
  return clamp(ri((balance * 0.65 + magnitude * balance * 0.35) * 100 + magnitude * 12), 0, 100);
}

export function strengthFromPulses(pulses) {
  return clamp(ri(mean(pulses.map((p) => p.strength))), 0, 100);
}

export function confidenceFromFeatures(f) {
  const stability = clamp(100 - (f.factorNoise - 12) * 2.2, 25, 100);
  const sample = clamp((f.sampleSize / 120) * 100, 0, 100);
  return clamp(ri(0.65 * stability + 0.35 * sample), 0, 100);
}

export function statusFor(contradiction, velocity) {
  if (contradiction >= 78) return "contradicted";
  if (Math.abs(velocity) >= 35) return "shifting";
  if (contradiction >= 50) return "diverging";
  return "confirmed";
}

export function riskFor(contradiction, status) {
  if (status === "contradicted" || contradiction >= 78) return "High";
  if (contradiction >= 52) return "Medium";
  return "Low";
}

/** Composite contradiction strength in [0,1] for a narrative as-of features. */
export function compositeFor(def, f) {
  return contradictionFromPulses(def.pulses(f)) / 100;
}

/** Build one fully-scored narrative object (minus shiftVelocity, set by caller). */
export function buildNarrative(def, f) {
  const pulses = def.pulses(f).map((p) => ({
    asset: p.asset,
    reading: p.reading,
    bias: p.bias,
    strength: clamp(ri(p.strength), 0, 100)
  }));
  const contradictionScore = contradictionFromPulses(pulses);
  return {
    id: def.id,
    title: def.title,
    summary: def.summary(f),
    lens: def.lens,
    confidence: confidenceFromFeatures(f),
    strength: strengthFromPulses(pulses),
    contradictionScore,
    affectedTickers: def.affectedTickers,
    evidence: def.evidence(f),
    crossAssetPulses: pulses,
    psychologyOverlay: def.psychology(f),
    representative: def.representative,
    _contradiction: contradictionScore
  };
}

export { toSignedScore };
