// engine/features.mjs
// Turns raw provider series into named, interpretable features computed *as of*
// a given bar index `t`. The same function powers the live snapshot (t = last),
// the shift-velocity slope (t and t-k), and every point in a backtest sweep.

import {
  mean,
  std,
  zscore,
  percentileRank,
  realizedVol,
  normalizedSlope,
  breadthAboveMa,
  pearson,
  logReturns
} from "./indicators.mjs";

const upto = (arr, t) => arr.slice(0, t + 1);
const last = (arr) => (arr.length ? arr[arr.length - 1] : 0);

/** Windowed percentage return over the last `w` bars. */
function windowReturn(prices, w) {
  if (prices.length <= w) return 0;
  const a = prices[prices.length - 1 - w];
  const b = prices[prices.length - 1];
  return a === 0 ? 0 : ((b - a) / a) * 100;
}

/** Relative-strength slope of a/b ratio over the last `w` bars (% per bar). */
function relStrengthSlope(a, b, w = 20) {
  const n = Math.min(a.length, b.length);
  const ratio = [];
  for (let i = Math.max(0, n - w); i < n; i++) {
    ratio.push(b[i] === 0 ? 0 : a[i] / b[i]);
  }
  return normalizedSlope(ratio) * 100;
}

export function featuresAsOf(market, t) {
  const b = market.bars;
  const m = market.macro;
  const px = (sym) => upto(b[sym].price, t);
  const ser = (sym, field) => upto(b[sym][field], t);
  const macro = (key) => upto(m[key], t);

  const spy = px("SPY");
  const smh = px("SMH");
  const qqqe = px("QQQE");
  const iwm = px("IWM");
  const tlt = px("TLT");
  const hyg = px("HYG");
  const us10y = macro("US10Y");
  const vix = macro("VIX");
  const move = macro("MOVE");
  const dxy = macro("DXY");

  // --- AI supercycle / breadth divergence -------------------------------
  const semiMomentum = windowReturn(smh, 20); // semis leadership
  const techBreadth = breadthAboveMa([qqqe, px("MSFT"), px("AMD"), px("NVDA"), smh], 50);
  const semiVsBroad = relStrengthSlope(smh, qqqe, 20); // semis outpacing equal-weight tech
  const yieldPressure = normalizedSlope(us10y.slice(-20)) * 100; // rising yields = discount pressure

  // --- Equity vs bond regime contradiction ------------------------------
  const equityTrend = windowReturn(spy, 20);
  const durationReturn = windowReturn(tlt, 20); // weak/negative => no safety bid
  const smallCapLag = windowReturn(spy, 20) - windowReturn(iwm, 20); // breadth lag
  const ratesVsEquityVol = mean(move.slice(-10)) / Math.max(1, mean(vix.slice(-10))); // MOVE/VIX

  // --- Volatility term / hedging stress ---------------------------------
  const spyDrawdown = (() => {
    const w = spy.slice(-20);
    if (w.length < 2) return 0;
    const peak = Math.max(...w);
    return ((last(w) - peak) / peak) * 100; // <= 0
  })();
  const spxSkewRank = percentileRank(last(ser("SPY", "skew")), ser("SPY", "skew")); // protection demand
  const creditTrend = windowReturn(hyg, 20); // credit stability
  const ivTrend = normalizedSlope(ser("SPY", "iv").slice(-15)) * 100; // vol bid building

  // --- Retail call activity vs liquidity --------------------------------
  const retailNames = ["TSLA", "COIN", "MARA", "ARKK"];
  const callZ = mean(
    retailNames.map((s) => {
      const cv = ser(s, "callVol");
      return zscore(last(cv), cv.slice(-40));
    })
  );
  const liquidityHeadwind = normalizedSlope(dxy.slice(-20)) * 100; // rising USD = liquidity drain
  const betaBreadth = breadthAboveMa([iwm, px("ARKK"), px("COIN")], 50);
  const speculativeDemand = windowReturn(px("ARKK"), 20);

  // --- Confidence inputs: how noisy / consistent is the current tape? ----
  const factorNoise = std(logReturns(spy.slice(-20))) * Math.sqrt(252) * 100; // realized vol proxy
  const sampleSize = t + 1;

  return {
    t,
    semiMomentum,
    techBreadth,
    semiVsBroad,
    yieldPressure,
    equityTrend,
    durationReturn,
    smallCapLag,
    ratesVsEquityVol,
    spyDrawdown,
    spxSkewRank,
    creditTrend,
    ivTrend,
    callZ,
    liquidityHeadwind,
    betaBreadth,
    speculativeDemand,
    factorNoise,
    sampleSize,
    levels: {
      vix: last(vix),
      move: last(move),
      us10y: last(us10y),
      dxy: last(dxy),
      spyRealizedVol: realizedVol(spy, 20)
    }
  };
}

/** Correlation of two instruments' returns over the last `w` bars (-1..1). */
export function returnCorrelation(market, symA, symB, w = 30) {
  const a = logReturns(market.bars[symA].price.slice(-(w + 1)));
  const b = logReturns(market.bars[symB].price.slice(-(w + 1)));
  return pearson(a, b);
}
