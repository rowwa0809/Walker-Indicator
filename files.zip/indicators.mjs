// engine/indicators.mjs
// Pure, dependency-free time-series math. Every function is total: it returns a
// finite number (or a safe default) even on short/degenerate input, so the
// scoring layer never has to guard against NaN.

export function clamp(x, lo, hi) {
  if (!Number.isFinite(x)) return lo;
  return Math.max(lo, Math.min(hi, x));
}

export function mean(xs) {
  if (!xs.length) return 0;
  let s = 0;
  for (const x of xs) s += x;
  return s / xs.length;
}

/** Sample standard deviation (n-1). Returns 0 for fewer than 2 points. */
export function std(xs) {
  if (xs.length < 2) return 0;
  const m = mean(xs);
  let s = 0;
  for (const x of xs) s += (x - m) * (x - m);
  return Math.sqrt(s / (xs.length - 1));
}

/** Simple period-over-period percentage change series. */
export function pctChange(series) {
  const out = [];
  for (let i = 1; i < series.length; i++) {
    const prev = series[i - 1];
    out.push(prev === 0 ? 0 : (series[i] - prev) / prev);
  }
  return out;
}

export function logReturns(series) {
  const out = [];
  for (let i = 1; i < series.length; i++) {
    const a = series[i - 1];
    const b = series[i];
    out.push(a > 0 && b > 0 ? Math.log(b / a) : 0);
  }
  return out;
}

/** Exponential moving average; returns the final value of the EMA series. */
export function ema(series, period) {
  if (!series.length) return 0;
  const k = 2 / (period + 1);
  let e = series[0];
  for (let i = 1; i < series.length; i++) e = series[i] * k + e * (1 - k);
  return e;
}

/** Annualized realized vol from a price series (252 trading days), as a %. */
export function realizedVol(prices, lookback = 20) {
  const rets = logReturns(prices.slice(-Math.min(lookback + 1, prices.length)));
  return std(rets) * Math.sqrt(252) * 100;
}

/** z-score of `value` relative to a reference series. */
export function zscore(value, series) {
  const s = std(series);
  if (s === 0) return 0;
  return (value - mean(series)) / s;
}

/** Percentile rank (0–100) of `value` within `series`. */
export function percentileRank(value, series) {
  if (!series.length) return 50;
  let below = 0;
  for (const x of series) if (x <= value) below++;
  return (below / series.length) * 100;
}

/** Pearson correlation of two equal-length series (uses the overlapping tail). */
export function pearson(a, b) {
  const n = Math.min(a.length, b.length);
  if (n < 3) return 0;
  const ax = a.slice(-n);
  const bx = b.slice(-n);
  const ma = mean(ax);
  const mb = mean(bx);
  let num = 0;
  let da = 0;
  let db = 0;
  for (let i = 0; i < n; i++) {
    const x = ax[i] - ma;
    const y = bx[i] - mb;
    num += x * y;
    da += x * x;
    db += y * y;
  }
  if (da === 0 || db === 0) return 0;
  return num / Math.sqrt(da * db);
}

/** Least-squares slope over index 0..n-1, normalized by mean level (% per bar). */
export function normalizedSlope(series) {
  const n = series.length;
  if (n < 3) return 0;
  const xm = (n - 1) / 2;
  const ym = mean(series);
  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (i - xm) * (series[i] - ym);
    den += (i - xm) * (i - xm);
  }
  if (den === 0) return 0;
  const slope = num / den;
  return ym === 0 ? slope : slope / Math.abs(ym);
}

/** Fraction (0–100) of a basket of series currently above their own SMA. */
export function breadthAboveMa(seriesList, period = 50) {
  if (!seriesList.length) return 50;
  let above = 0;
  for (const s of seriesList) {
    if (s.length < 2) continue;
    const window = s.slice(-Math.min(period, s.length));
    if (s[s.length - 1] > mean(window)) above++;
  }
  return (above / seriesList.length) * 100;
}

/** Map a z-score to a 0–100 intensity via a logistic squash (|z|~2 ≈ ~88). */
export function zToIntensity(z) {
  const v = 100 / (1 + Math.exp(-Math.abs(z)));
  return clamp((v - 50) * 2, 0, 100);
}

/** Map a signed value in [-1,1]-ish range to a -100..100 scale. */
export function toSignedScore(x, scale = 1) {
  return clamp(Math.round((x / scale) * 100), -100, 100);
}
