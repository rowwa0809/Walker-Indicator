// engine/providers/synthetic.mjs
// A deterministic, seeded synthetic market. NOT real data — it exists so the
// engine runs end-to-end with zero external dependencies and produces stable,
// reproducible output. A common "risk factor" drives a correlated cross-asset
// world; each instrument has a beta to it plus idiosyncratic noise, so genuine
// correlations and divergences emerge for the feature layer to measure.
//
// To wire a real feed, implement the same shape in providers/http.mjs:
//   { meta, bars: { TICKER: { price[], iv[], skew[], callVol[] } }, macro: { KEY: level[] } }

import { mulberry32, hashSeed, gaussian } from "../prng.mjs";

// Instrument universe. beta = sensitivity to the risk factor; vol = idiosyncratic.
// retail=true names get episodic call-volume spikes (chase behavior).
const EQUITIES = {
  SPY: { beta: 1.0, vol: 0.008 },
  QQQ: { beta: 1.15, vol: 0.011 },
  QQQE: { beta: 0.95, vol: 0.009 }, // equal-weight tech (breadth proxy)
  IWM: { beta: 1.25, vol: 0.013 }, // small caps (beta breadth)
  SMH: { beta: 1.5, vol: 0.018 }, // semis (AI leadership)
  NVDA: { beta: 1.7, vol: 0.024 },
  AMD: { beta: 1.6, vol: 0.026 },
  MSFT: { beta: 1.1, vol: 0.012 },
  TLT: { beta: -0.6, vol: 0.009 }, // long duration (risk-off bid)
  HYG: { beta: 0.4, vol: 0.005 }, // high-yield credit
  ARKK: { beta: 1.8, vol: 0.03 },
  TSLA: { beta: 1.6, vol: 0.03, retail: true },
  COIN: { beta: 1.9, vol: 0.04, retail: true },
  MARA: { beta: 2.1, vol: 0.05, retail: true }
};

const DEFAULTS = { bars: 200, seed: 20260530 };

function buildFactor(rng, n) {
  // Risk sentiment as a slow regime drift plus shocks. Positive => risk-on.
  const f = [0];
  let regime = 0.0006; // gentle upward drift to start
  for (let i = 1; i < n; i++) {
    if (rng() < 0.02) regime = (rng() - 0.45) * 0.004; // occasional regime shift
    const shock = gaussian(rng) * 0.006;
    f.push(f[i - 1] + regime + shock);
  }
  return f;
}

function buildPrice(symbol, cfg, factorRet, n, baseSeed) {
  const rng = mulberry32((baseSeed ^ hashSeed(symbol)) >>> 0);
  const price = [100];
  for (let i = 1; i < n; i++) {
    const idio = gaussian(rng) * cfg.vol;
    const ret = cfg.beta * factorRet[i] + idio;
    price.push(Math.max(1, price[i - 1] * (1 + ret)));
  }
  return { rng, price };
}

function buildOptions(symbol, cfg, price, factor, rng) {
  const n = price.length;
  const iv = [];
  const skew = [];
  const callVol = [];
  for (let i = 0; i < n; i++) {
    const win = price.slice(Math.max(0, i - 20), i + 1);
    let rv = 18;
    if (win.length > 2) {
      const rets = [];
      for (let j = 1; j < win.length; j++) rets.push(Math.log(win[j] / win[j - 1]));
      const m = rets.reduce((a, b) => a + b, 0) / rets.length;
      const v = rets.reduce((a, b) => a + (b - m) * (b - m), 0) / Math.max(1, rets.length - 1);
      rv = Math.sqrt(v * 252) * 100;
    }
    // IV = realized vol + volatility-risk premium + noise.
    iv.push(Math.max(6, rv + 4 + gaussian(rng) * 2));
    // Put skew rises as the factor falls (demand for downside protection).
    const factorMom = i >= 5 ? factor[i] - factor[i - 5] : 0;
    skew.push(Math.max(0, 8 - factorMom * 600 + gaussian(rng) * 1.5));
    // Call volume: baseline + risk-on tilt + episodic retail chase spikes.
    let cv = 100 + Math.max(0, factorMom) * 4000 + gaussian(rng) * 12;
    if (cfg.retail && rng() < 0.08) cv *= 1.8 + rng();
    callVol.push(Math.max(1, cv));
  }
  return { iv, skew, callVol };
}

function buildMacroLevels(factor, n, baseSeed) {
  const rng = mulberry32((baseSeed ^ hashSeed("MACRO")) >>> 0);
  const US10Y = [4.2];
  const MOVE = []; // rates (bond) volatility
  const VIX = []; // equity volatility
  const DXY = [103];
  for (let i = 0; i < n; i++) {
    const factorMom = i >= 5 ? factor[i] - factor[i - 5] : 0;
    if (i > 0) US10Y.push(Math.max(0.5, US10Y[i - 1] + gaussian(rng) * 0.03));
    // VIX falls when risk sentiment rises, with a floor.
    VIX.push(Math.max(9, 17 - factorMom * 700 + gaussian(rng) * 1.2));
    // MOVE (rates vol) is stickier and partly independent of equity calm.
    MOVE.push(Math.max(60, 95 + Math.abs(US10Y[i] - 4.2) * 40 + gaussian(rng) * 5));
    if (i > 0) DXY.push(Math.max(80, DXY[i - 1] - factorMom * 30 + gaussian(rng) * 0.25));
  }
  return { US10Y, MOVE, VIX, DXY };
}

export function fetchMarket(options = {}) {
  const { bars: n, seed } = { ...DEFAULTS, ...options };
  const factorRng = mulberry32(seed >>> 0);
  const factor = buildFactor(factorRng, n);
  const factorRet = [0];
  for (let i = 1; i < n; i++) factorRet.push(factor[i] - factor[i - 1]);

  const bars = {};
  for (const [symbol, cfg] of Object.entries(EQUITIES)) {
    const { rng, price } = buildPrice(symbol, cfg, factorRet, n, seed);
    const opt = buildOptions(symbol, cfg, price, factor, rng);
    bars[symbol] = { price, ...opt };
  }

  const macro = buildMacroLevels(factor, n, seed);

  const today = new Date("2026-05-30T13:45:00.000Z");
  const dates = [];
  for (let i = n - 1; i >= 0; i--) {
    dates.unshift(new Date(today.getTime() - i * 86400000).toISOString());
  }

  return {
    meta: { provider: "synthetic", seed, bars: n, generatedAt: today.toISOString() },
    dates,
    bars,
    macro,
    factor
  };
}
