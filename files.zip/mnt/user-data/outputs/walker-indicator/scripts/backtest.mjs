// scripts/backtest.mjs
// Prints backtest diagnostics. Run: npm run backtest
// Reminder: synthetic provider => in-sample diagnostic over simulated data.

import { runBacktest } from "../engine/backtest.mjs";

const horizon = process.env.BT_HORIZON ? Number(process.env.BT_HORIZON) : 5;
const report = await runBacktest({ horizon });

console.log(`\nWalker Indicator backtest  ·  provider=${report.meta.provider}  ·  horizon=${horizon} bars`);
console.log(`seed=${report.meta.seed}  bars=${report.meta.bars}\n`);
console.log("narrative".padEnd(30), "rep".padEnd(6), "n".padEnd(5), "avgContra", "corr", "hi→down%");
console.log("-".repeat(72));
for (const r of report.results) {
  console.log(
    r.id.padEnd(30),
    r.representative.padEnd(6),
    String(r.samples).padEnd(5),
    String(r.avgContradiction).padEnd(9),
    String(r.contradictionVsForwardReturnCorr).padEnd(5),
    r.highContradictionDownRate === null ? "n/a" : `${r.highContradictionDownRate}%`
  );
}
console.log("\nNote: synthetic data => illustrative only, not validated edge.\n");
