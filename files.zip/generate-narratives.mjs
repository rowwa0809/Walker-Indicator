// scripts/generate-narratives.mjs
// Regenerates data/narratives.json from the computed engine output, then it can be
// validated with the existing contract checker. Run: npm run generate
// Optional env: MARKET_SEED, MARKET_BARS, MARKET_PROVIDER.

import { writeFile } from "node:fs/promises";
import { generatePayload } from "../engine/generate.mjs";

const seed = process.env.MARKET_SEED ? Number(process.env.MARKET_SEED) : undefined;
const bars = process.env.MARKET_BARS ? Number(process.env.MARKET_BARS) : undefined;

const payload = await generatePayload({
  ...(seed !== undefined ? { seed } : {}),
  ...(bars !== undefined ? { bars } : {})
});

// data/narratives.json is the fallback contract: strip engine-only metadata
// (source/warning/meta are added back at request time by the server).
const { source, warning, meta, ...contract } = payload;

const target = new URL("../data/narratives.json", import.meta.url);
await writeFile(target, JSON.stringify(contract, null, 2) + "\n", "utf8");

console.log(
  `Generated ${contract.narratives.length} computed narratives ` +
    `(provider=${meta.provider}, seed=${meta.seed}, bars=${meta.bars}) -> data/narratives.json`
);
