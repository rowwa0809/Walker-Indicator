// engine/providers/http.mjs
// Adapter seam for a REAL market-data feed (e.g. Polygon, Tradier, ORATS, CBOE).
// Not implemented here because live options/vol data requires a paid API key and
// outbound network access. Implement fetchMarket() to return the exact shape the
// synthetic provider returns, and the rest of the engine works unchanged.
//
// Expected return shape:
//   {
//     meta:  { provider, generatedAt, ... },
//     dates: string[],                              // ISO timestamps, oldest -> newest
//     bars:  { [TICKER]: { price:[], iv:[], skew:[], callVol:[] } },
//     macro: { US10Y:[], MOVE:[], VIX:[], DXY:[] }  // level series
//   }
//
// Set MARKET_PROVIDER=http and MARKET_API_KEY=... to route here once built.

export async function fetchMarket() {
  throw new Error(
    "http provider not configured. Set MARKET_PROVIDER=synthetic, or implement " +
      "engine/providers/http.mjs against your data vendor and provide MARKET_API_KEY."
  );
}
