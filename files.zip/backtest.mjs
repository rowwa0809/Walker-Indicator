// engine/backtest.mjs
// A minimal, honest backtest harness. For each narrative it sweeps the contradiction
// score across history and measures the forward k-bar return of the narrative's
// representative instrument. It reports the correlation between contradiction and
// forward return (thesis: high contradiction precedes weakness) plus a naive hit-rate.
//
// IMPORTANT: on the synthetic provider this is an IN-SAMPLE diagnostic over
// SIMULATED data. It demonstrates the harness, not validated edge. Point it at a
// real provider with true out-of-sample history before trusting any number.

import { getMarket } from "./providers/index.mjs";
import { featuresAsOf } from "./features.mjs";
import { pearson, mean } from "./indicators.mjs";
import { NARRATIVES, compositeFor } from "./scoring.mjs";

export async function runBacktest({ horizon = 5, warmup = 60, ...marketOptions } = {}) {
  const market = await getMarket(marketOptions);
  const n = market.dates.length;
  const results = [];

  for (const def of NARRATIVES) {
    const price = market.bars[def.representative].price;
    const contradictions = [];
    const forwardReturns = [];

    for (let t = warmup; t < n - horizon; t++) {
      const f = featuresAsOf(market, t);
      const contradiction = compositeFor(def, f); // 0..1
      const fwd = (price[t + horizon] - price[t]) / price[t];
      contradictions.push(contradiction);
      forwardReturns.push(fwd);
    }

    // Correlation: expect negative (high contradiction -> lower forward return).
    const corr = pearson(contradictions, forwardReturns);

    // Hit-rate: when contradiction is in its top tercile, how often is the
    // forward return negative?
    const sorted = [...contradictions].sort((a, b) => a - b);
    const cut = sorted[Math.floor(sorted.length * 0.66)] ?? 1;
    let hi = 0;
    let hiNeg = 0;
    for (let i = 0; i < contradictions.length; i++) {
      if (contradictions[i] >= cut) {
        hi++;
        if (forwardReturns[i] < 0) hiNeg++;
      }
    }

    results.push({
      id: def.id,
      representative: def.representative,
      samples: contradictions.length,
      horizonBars: horizon,
      avgContradiction: Math.round(mean(contradictions) * 100),
      contradictionVsForwardReturnCorr: Math.round(corr * 100) / 100,
      highContradictionDownRate: hi ? Math.round((hiNeg / hi) * 100) : null
    });
  }

  return { meta: market.meta, horizon, warmup, results };
}
