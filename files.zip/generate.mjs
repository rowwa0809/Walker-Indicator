// engine/generate.mjs
// Orchestrates the pipeline into the exact payload shape the frontend + validator
// expect: { marketWeather, narratives, source, warning, meta }.
// shiftVelocity is the change in a narrative's contradiction over ~10 bars, so it
// reflects whether the story is intensifying or fading — computed, not authored.

import { getMarket } from "./providers/index.mjs";
import { featuresAsOf } from "./features.mjs";
import { clamp, mean } from "./indicators.mjs";
import { NARRATIVES, buildNarrative, compositeFor, statusFor, riskFor, toSignedScore } from "./scoring.mjs";

const VELOCITY_LOOKBACK = 10;

function marketWeather(market, lastT, narratives) {
  const f = featuresAsOf(market, lastT);
  const lv = f.levels;

  const trend = f.equityTrend;
  let regime;
  if (trend > 3 && f.techBreadth > 55) regime = "Expansion";
  else if (trend > 0.5) regime = "Recovery";
  else if (trend < -3 && f.techBreadth < 45) regime = "Contraction";
  else if (trend < -0.5) regime = "Slowdown";
  else regime = "Transition";

  const temperature = clamp(Math.round(50 + f.equityTrend * 3), 0, 100);
  const liquidity = clamp(Math.round(55 - f.liquidityHeadwind * 9 + f.creditTrend * 2), 0, 100);
  const stress = clamp(Math.round((lv.vix - 10) * 4 + (lv.move - 90) * 0.55), 0, 100);
  const avgConf = mean(narratives.map((n) => n.confidence));
  const avgContra = mean(narratives.map((n) => n.contradictionScore));
  const narrativeClarity = clamp(Math.round(0.5 * avgConf + 0.5 * (100 - avgContra)), 0, 100);

  // Radar axes (0..1) = raw macro levels vs their own norms (drive the radar SVG).
  const macroAxes = {
    Inflation: clamp((lv.us10y - 2.5) / 3, 0, 1),
    Growth: clamp(0.5 + f.equityTrend / 16, 0, 1),
    Rates: clamp(0.5 + f.yieldPressure / 2, 0, 1),
    Employment: clamp(f.techBreadth / 100, 0, 1),
    Liquidity: clamp(liquidity / 100, 0, 1),
    Sentiment: clamp(0.55 - (lv.vix - 16) / 26 + f.callZ / 8, 0, 1)
  };

  // Scorecard = favorability-for-risk per axis (drives the scorecard SVG/bars).
  // Same computed inputs as the radar, but reframed so the existing display
  // semantics hold (green confirms, amber qualifies, red contradicts). For
  // Inflation and Rates, a *lower* level is the risk-supportive reading, so we
  // invert them; the others read directly.
  const favorability = {
    Growth: macroAxes.Growth,
    Inflation: 1 - macroAxes.Inflation,
    Rates: 1 - macroAxes.Rates,
    Employment: macroAxes.Employment,
    Liquidity: macroAxes.Liquidity,
    Sentiment: macroAxes.Sentiment
  };
  const scorecard = ["Growth", "Inflation", "Rates", "Employment", "Liquidity", "Sentiment"].map(
    (label) => {
      const score = clamp(Math.round(favorability[label] * 100), 0, 100);
      const tone = score >= 60 ? "green" : score >= 40 ? "amber" : "red";
      return { label, score, tone };
    }
  );

  return { regime, temperature, liquidity, stress, narrativeClarity, macroAxes, scorecard };
}

export async function generatePayload(options = {}) {
  const market = await getMarket(options);
  const lastT = market.dates.length - 1;
  const prevT = Math.max(0, lastT - VELOCITY_LOOKBACK);
  const fNow = featuresAsOf(market, lastT);
  const fPrev = featuresAsOf(market, prevT);

  const narratives = NARRATIVES.map((def) => {
    const n = buildNarrative(def, fNow);
    const compNow = n._contradiction / 100;
    const compPrev = compositeFor(def, fPrev);
    const shiftVelocity = toSignedScore(compNow - compPrev, 0.55);
    const status = statusFor(n.contradictionScore, shiftVelocity);
    const riskLabel = riskFor(n.contradictionScore, status);
    const { representative, _contradiction, ...rest } = n;
    return {
      ...rest,
      shiftVelocity,
      status,
      riskLabel,
      updatedAt: market.meta.generatedAt
    };
  });

  narratives.sort((a, b) => b.contradictionScore - a.contradictionScore);

  return {
    marketWeather: marketWeather(market, lastT, narratives),
    narratives,
    source: "engine",
    warning: null,
    meta: market.meta
  };
}
