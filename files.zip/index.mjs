// engine/providers/index.mjs
// Selects a data provider by environment. Defaults to the synthetic feed so the
// app runs out of the box; set MARKET_PROVIDER=http to use a real vendor adapter.

import { fetchMarket as synthetic } from "./synthetic.mjs";

export async function getMarket(options = {}) {
  const provider = (process.env.MARKET_PROVIDER || "synthetic").toLowerCase();
  if (provider === "http") {
    const mod = await import("./http.mjs");
    return mod.fetchMarket(options);
  }
  return synthetic(options);
}
